#pragma once
#include "social.h"  // Includes Peasant, Merchant, Noble
using namespace std;

class Economy {
private:
    int treasury;        // Total gold
    float inflation;     // Inflation rate (e.g., 1.05 = 5%)
    int militaryBudget;  // Funds for army
    int foodBudget;      // Funds for food

public:
    Economy();  // Constructor

    // Core functions
    void collectTaxes(SocialClass* classes[], int classCount);
    void adjustInflation(int totalSpending);
    void allocateBudget(int military, int food);

    // Getters
    int getTreasury();
    float getInflation();
};
