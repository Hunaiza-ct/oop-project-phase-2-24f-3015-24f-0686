#pragma once
#include <iostream>
using namespace std;

class Economy;  // Forward declaration

class Bank {
private:
    int totalGold;          // Bank's reserves
    float interestRate;     // Current loan interest (e.g., 0.1 for 10%)
    int corruptionLevel;    // 0-100 scale (100 = highly corrupt)

public:
    Bank(Economy eco);

    // Core functions
    bool grantLoan(Economy& economy, int amount);
    void detectFraud(Economy& economy);
    void adjustInterestRates(int inflation);

    // New: Banking crisis event
    void triggerBankRun(Economy& economy);

    // Getters
    int getGoldReserves();
    float getInterestRate();
};

