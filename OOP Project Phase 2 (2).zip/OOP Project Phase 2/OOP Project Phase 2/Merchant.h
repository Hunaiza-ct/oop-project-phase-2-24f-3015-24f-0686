#pragma once
#include "social.h"

class Merchant : public SocialClass {
public:
    Merchant();
    void payTax() override;
    int getInfluence() override;
};
