#include "Economy.h"

// Constructor: Starts with 5000 gold and 0% inflation
Economy::Economy() : treasury(5000), inflation(1.0), militaryBudget(0), foodBudget(0) {}

// Collects taxes from all social classes (array version)
void Economy::collectTaxes(SocialClass* classes[], int classCount) {
    if (classCount <= 0) {
        cout << "Warning: No social classes to collect taxes from!" << endl;
        return;
    }
    for (int i = 0; i < classCount; i++) {
        classes[i]->payTax();
        treasury += classes[i]->getInfluence() * 10;  // Tax based on influence
    }
    cout << "Taxes collected! Treasury: " << treasury << endl;
}

// Adjusts inflation based on spending
void Economy::adjustInflation(int totalSpending) {
    if (totalSpending > treasury / 2) {
        inflation *= 1.1;  // High spending = 10% inflation
        cout << "Inflation rises to " << (inflation - 1) * 100 << "%" << endl;
    }
}

// Allocates funds to military and food
void Economy::allocateBudget(int military, int food) {
    militaryBudget = military;
    foodBudget = food;
    treasury -= (military + food);
    cout << "Budget allocated - Military: " << military
        << ", Food: " << food << endl;
}

// Getters
int Economy::getTreasury() { return treasury; }
float Economy::getInflation() { return inflation; }
