#pragma once
#include <iostream>
using namespace std;

class Population;  // Forward declaration

class Military {
private:
    int soldierCount;     // Current army size
    int morale;           // Loyalty level (1-100)
    int trainingLevel;    // Training quality (1-10)
    int weapons;          // Weapon stockpile

public:
    Military();
    int armyStrength=0;
    // Core functions
    void recruitSoldiers(Population& population, int recruits);
    void trainArmy(int days);
    void checkMorale(int foodSupply, int goldPayment);
    bool fightBattle(int enemyStrength);  // New: Simulate battle

    // Getters
    int getSoldierCount();
    int getArmyStrength();
    int getMorale();

    // Setters
    void setWeapons(int count);
};