#pragma once
#include <iostream>
using namespace std;

class Population;  // Forward declarations
class Military;

class ResourceManager {
private:
    // Individual resource tracking
    int food;
    int wood;
    int iron;
    int stone;

public:
    ResourceManager();

    // Core functions
    void harvestFood(int amount);
    void harvestWood(int amount);
    void harvestIron(int amount);

    void consumeFood(int amount);
    void consumeWood(int amount);
    void consumeIron(int amount);

    bool tradeFoodForWood(int foodAmount, int woodAmount);
    bool tradeWoodForIron(int woodAmount, int ironAmount);

    // Special events
    void handleDrought();
    void handleBumperCrop();

    // Getters
    int getFood() const;
    int getWood() const;
    int getIron() const;
    int getStone() const;

    // Display
    void printResources() const;
};
