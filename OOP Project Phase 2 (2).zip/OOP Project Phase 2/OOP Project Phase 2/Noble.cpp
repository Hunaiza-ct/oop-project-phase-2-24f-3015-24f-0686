#include "Noble.h"

Noble::Noble() : SocialClass("Noble", 10, 50) {
    happiness = 80;
}

void Noble::payTax() {
    cout << "Noble pays " << taxRate << "% tax (reluctantly)" << endl;
    happiness -= 10;
}

void Noble::demandRights() {
    if (happiness < 50) {
        cout << "Nobles are plotting a coup!" << endl;
    }
}