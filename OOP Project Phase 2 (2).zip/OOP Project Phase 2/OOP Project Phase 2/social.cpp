#include "social.h"

SocialClass::SocialClass(string name, int tax, int inf): className(name), taxRate(tax), influence(inf), happiness(70) {}

void SocialClass::demandRights() {
    cout << className << " demands better rights!" << endl;
}

int SocialClass::getInfluence() {
    return influence;
}

string SocialClass::getClassName() {
    return className;
}

int SocialClass::getHappiness() {
    return happiness;
}