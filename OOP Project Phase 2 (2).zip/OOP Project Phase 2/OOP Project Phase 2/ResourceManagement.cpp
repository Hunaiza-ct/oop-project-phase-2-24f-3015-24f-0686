#include "ResourceManagement.h"
#include "Population.h"
#include "Military.h"

// Initialize starting resources
ResourceManager::ResourceManager()
    : food(1000), wood(500), iron(200), stone(100) {
}

// Harvesting functions
void ResourceManager::harvestFood(int amount) {
    food += amount;
    cout << "Harvested " << amount << " food" << endl;
}

void ResourceManager::harvestWood(int amount) {
    wood += amount;
    cout << "Harvested " << amount << " wood" << endl;
}

void ResourceManager::harvestIron(int amount) {
    iron += amount;
    cout << "Harvested " << amount << " iron" << endl;
}

// Consumption functions
void ResourceManager::consumeFood(int amount) {
    if (food >= amount) {
        food -= amount;
    }
    else {
        cout << "WARNING! Not enough food (Missing: " << amount - food << ")" << endl;
        food = 0;
    }
}

void ResourceManager::consumeWood(int amount) {
    if (wood >= amount) {
        wood -= amount;
    }
    else {
        cout << "WARNING! Not enough wood" << endl;
        wood = 0;
    }
}

void ResourceManager::consumeIron(int amount) {
    if (iron >= amount) {
        iron -= amount;
    }
    else {
        cout << "WARNING! Not enough iron" << endl;
        iron = 0;
    }
}

// Trading functions
bool ResourceManager::tradeFoodForWood(int foodAmount, int woodAmount) {
    if (food >= foodAmount) {
        food -= foodAmount;
        wood += woodAmount;
        cout << "Traded " << foodAmount << " food for " << woodAmount << " wood" << endl;
        return true;
    }
    cout << "Trade failed! Not enough food" << endl;
    return false;
}

bool ResourceManager::tradeWoodForIron(int woodAmount, int ironAmount) {
    if (wood >= woodAmount) {
        wood -= woodAmount;
        iron += ironAmount;
        cout << "Traded " << woodAmount << " wood for " << ironAmount << " iron" << endl;
        return true;
    }
    cout << "Trade failed! Not enough wood" << endl;
    return false;
}

// Special events
void ResourceManager::handleDrought() {
    food *= 0.7;  // Lose 30% food
    cout << "DROUGHT! Food supplies reduced" << endl;
}

void ResourceManager::handleBumperCrop() {
    food *= 1.5;  // Gain 50% more food
    cout << "BUMPER CROP! Extra food harvested" << endl;
}

// Getters
int ResourceManager::getFood() const { return food; }
int ResourceManager::getWood() const { return wood; }
int ResourceManager::getIron() const { return iron; }
int ResourceManager::getStone() const { return stone; }

void ResourceManager::printResources() const {
    cout << "\n=== Resources ===" << endl;
    cout << "Food: " << food << endl;
    cout << "Wood: " << wood << endl;
    cout << "Iron: " << iron << endl;
    cout << "Stone: " << stone << endl;
}