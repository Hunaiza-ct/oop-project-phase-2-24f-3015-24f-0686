#pragma once
#include <iostream>
#include <cstdlib>  // For rand()
#include <ctime>    // For time()
using namespace std;

class Population;  // Forward declarations
class Economy;
class Military;

class EventSystem {
private:
    int eventSeverity;  // 1-10 scale

public:
    EventSystem();

    // Core functions
    void triggerEvent(Population& pop, Economy& economy, Military& military);
    void resolveEvent(int responseChoice, Population& pop, Economy& economy);

    // New: Special event effects
    void applyFamine(Population& pop);
    void applyPlague(Population& pop);
    void applyWar(Economy& economy, Military& military);
};
