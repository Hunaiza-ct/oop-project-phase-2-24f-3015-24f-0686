#include "EventSystem.h"
#include "Population.h"
#include "Economy.h"
#include "Military.h"

EventSystem::EventSystem() {
    srand(time(0));  // Seed random number generator
    eventSeverity = 5;  // Default severity
}

// Triggers a random event
void EventSystem::triggerEvent(Population& pop, Economy& economy, Military& military) {
    int eventType = rand() % 3;  // 0=Famine, 1=Plague, 2=War

    cout << "\n=== EVENT TRIGGERED ===" << endl;
    switch (eventType) {
    case 0:
        applyFamine(pop);
        break;
    case 1:
        applyPlague(pop);
        break;
    case 2:
        applyWar(economy, military);
        break;
    }
}

// Player chooses how to respond
void EventSystem::resolveEvent(int choice, Population& pop, Economy& economy) {
    cout << "Resolving event..." << endl;
    switch (choice) {
    case 1:  // Spend gold to fix
        economy.allocateBudget(-500, 0);
        pop.updatePopulation(50);  // Recover some population
        cout << "Spent 500 gold to mitigate effects" << endl;
        break;
    case 2:  // Do nothing
        cout << "No action taken - consequences worsen" << endl;
        eventSeverity += 2;
        break;
    }
}

// Event effects
void EventSystem::applyFamine(Population& pop) {
    cout << "FAMINE! Crops have failed" << endl;
    pop.updatePopulation(-100);  // Lose population
    pop.calculateHappiness(-20); // Happiness drops
}

void EventSystem::applyPlague(Population& pop) {
    cout << "PLAGUE! Disease spreads" << endl;
    pop.updatePopulation(-150);  // Bigger population hit
}

void EventSystem::applyWar(Economy& economy, Military& military) {
    cout << "WAR DECLARED!" << endl;
    economy.allocateBudget(1000, 0);  // War costs
    military.trainArmy(3);            // Emergency training
}