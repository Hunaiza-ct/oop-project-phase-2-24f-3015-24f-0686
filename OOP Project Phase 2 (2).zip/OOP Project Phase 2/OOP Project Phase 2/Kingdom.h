#pragma once
#include "Population.h"
#include "Military.h"
#include "Economy.h"
#include "Bank.h"
#include "Leader.h"
#include "EventSystem.h"
#include "ResourceManagement.h"
#include "Peasant.h"
#include "Merchant.h"
#include "Noble.h"
using namespace std;
class Kingdom {
private:
    int gold;       // Treasury money
    int food;       // Food supply
    int populations; // Number of people
    bool isGameOver; // Tracks if the game ended
    Population population;
    Military military;
    Economy economy;
    Bank bank;
    Leader leader;
    EventSystem events;
    ResourceManager resources;
    int dayCount;
    void showMenu();
    void handleChoice(int choice);
    void updateGameState();
    void displayStatus();

public:
    Kingdom();      // Constructor (initialize values)
    void runSimulation();  // Main game loop
    void handleRandomEvents(); // Triggers random disasters
    bool checkGameOver(); // Checks if kingdom collapsed
};