#pragma once
#include <iostream>
#include <string>
using namespace std;

class Military;  // Forward declaration
class Economy;   // Forward declaration

class Leader {
private:
    string name;
    string title;       // "King", "President", etc.
    bool isDemocratic;  // True for elected leaders
    int approvalRating; // 0-100%
    int termYears;      // Years in power

public:
    Leader(string leaderName, string leaderTitle, bool democratic);

    // Core functions
    void holdElection(Economy& economy);
    void handleCoup(Military& military);
    void declareWar(Military& military, Economy& economy);

    // New: Diplomatic actions
    void makePeace();
    void corruptTreasury(Economy& economy);

    // Getters
    string getName();
    string getTitle();
    int getApproval();
};

